# 暗夜鎏金

[English](README.md) | 中文

暗色专用 dsh 皮肤：暖黑漆底配香槟金，鎏金 SVG 花纹，以及一枚羽化过的立绘背景。
浅色与深色两套配色最终指向同一套呈现，所以 `preview/light.jpg` 与
`preview/dark.jpg` 本来就是同一张渲染图。

## 这是什么

- **纯资产**：`skin.json`（v2 清单）+ `skin.css`（完整的 `--dsw-alias-*`
  token 重映射）+ `patches.css`（L3 自由选择器）+ 目录内 13 个 SVG。
  无 package.json、无构建步骤、无 hooks。
- **构造上就是暗色**：调色板同时声明在 `:root` 与
  `body[data-ds-dark-theme]` 上，每条 L3 规则都去掉了明暗分支，并用
  `html { color-scheme: dark !important }` 钉死原生控件。市场渲染器只注入样式、
  不跑加载器的 `:root` → `body` token 克隆，所以调色板也声明在 `body` 上。
- **结构性 token 显式写出**：官方「永不派生」的 14 个 token（按钮 / 状态 / 遮罩 /
  阴影 / 反色标签几组）在这里显式给出。缺了它们，浅色方案会退回官方浅色值——
  「回到底部」按钮就会渲染成白色圆钮。

## 配色

- 底：暖黑漆 `#0a0806` .. `#221b15`
- 墨：淡香槟 `#f2e9d4`
- 主色：香槟金 `#c9ab6e`（高光 `#f5e9cf`，暗部 `#9c8045`）
- 警示：朱红 `#c9402f`——全套皮肤唯一的红，只留给等待审批的面板

## 装饰

视口四角缠枝角花、顶部回纹带、双线描金边、金箔碎屑叠金属拉丝、侧栏右缘描金双线、
压在细线上的鲸鱼印、回合之间的云纹分隔线、工作区描金匾额、输入卡四角开光与聚焦金光，
以及鎏金字标（双环徽章、菱花分隔、字标下的描金线）。

## 背景

立绘置于右下、`auto 88%`，以整层 `blur(1.7px)` 羽化；该层 `inset: -48px`，
好让模糊的软边落在视口之外。横向渐变压暗保住正文列在她的亮部之上可读。

## 素材与许可

`assets/liujin-bg.png` 是作者为本皮肤制作的自有立绘：黑金礼装的金发鲸鱼娘。
她与作者其他皮肤（`whale-maid` / `whale-song` / `whale-mom` /
`wallpaper-exclusive`）里的鲸鱼娘同属作者自有的角色线。`assets/` 中 13 个
SVG 由作者自己的装饰生成器产出。本目录不含任何第三方素材。

皮肤工程（`skin.json` / `skin.css` / `patches.css`）与 `assets/` 中的
全部素材均为作者原创，按
[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) 发布
（署名 — 非商业性使用 — 相同方式共享）。详见 `skin.json` 的 `license` /
`licenseUrl` / `attribution` 字段。

## 预览

`preview/light.jpg` 与 `preview/dark.jpg` 相同——本皮肤按设计就是暗色专用。
